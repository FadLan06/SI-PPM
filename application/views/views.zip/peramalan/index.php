<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-2 text-gray-800"><?=$title?></h1>
  <p class="mb-4"></p>

  <!-- DataTales Example -->
  <div class="card shadow mb-4">
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold float-right text-primary">Data <?=$title?></h6>
    </div>
    <div class="card-body">
      <form method="post">
        <div class="form-row align-items-center">
          <div class="col-md-4 my-1">
            <label class="mr-sm-2 sr-only" for="inlineFormCustomSelect">Preference</label>
            <select class="custom-select mr-sm-2" name="tahun" id="inlineFormCustomSelect">
              <option selected>Pilih Tahun</option>
              <option value="2018">2018</option>
              <option value="2019">2019</option>
            </select>
          </div>
          <div class="col-md-4 my-1">
            <label class="mr-sm-2 sr-only" for="inlineFormCustomSelect">Preference</label>
            <select class="custom-select mr-sm-2" name="tipe" id="inlineFormCustomSelect">
              <option selected>Pilih Tipe Kendaraan</option>
              <option value="XPANDER">XPANDER</option>
              <option value="OUTLANDER">OUTLANDER</option>
              <option value="PAJERO">PAJERO</option>
              <option value="MIRAGE">MIRAGE</option>
              <option value="STRADA">STRADA</option>
              <option value="TRITON">TRITON</option>
            </select>
          </div>
          <div class="col-md-2 my-1">
            <button type="submit" class="btn btn-primary" name="cari">Cari</button>
          </div>
        </div>
      </form>
    </div>
  </div>
  <?php if(isset($_POST['cari'])): ?>
    <div class="card shadow mb-4">
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-hover table-sm" width="100%" cellspacing="0">
            <thead>
              <tr align="center">
                <th width="12%">Periode</th>
                <th width="8%">Jumlah</th>
                <th width="8%">S't</th>
                <th width="8%">S''t</th>
                <th width="8%">at</th>
                <th width="10%">bt</th>
                <th width="8%">Forecast</th>
                <th width="8%">Error</th>
                <th width="8%">MAD</th>
                <th width="8%">MSE</th>
                <th width="8%">MAPE%</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $no=0;
                $total_jum=0;
                foreach($pen->result() as $data):
                  $bulan = date("m",strtotime($data->tgl_penjualan)); 
                  $tahun = date("Y",strtotime($data->tgl_penjualan)); 
                  $jum = $this->db->query("SELECT COUNT(singkat) as singkat FROM `historis` WHERE MONTH(tgl_penjualan)='$bulan' AND YEAR(tgl_penjualan)='$_POST[tahun]' AND singkat='$_POST[tipe]' ")->row();

                  $jumlah=2;
                  $no+=1;
              ?>
                <tr align="center">
                  <td><?=date('F Y', strtotime($data->tgl_penjualan))?></td>
                  <?php
                    for($x=1;$x<=1;$x++){
                      echo '<td><input type="text" id="singkat'.$no.'" value="'.$jum->singkat.'" style="width: 60%"></td>';
                      $noo=0;
                      for($i=1;$i<=2;$i++){
                        $noo+=1;
                        echo '<td><input type="text" id="s'.$no.'t'.$noo.'" style="width: 60%"></td>';
                      }
                        echo '<td><input type="text" id="at'.$no.'" style="width: 60%"></td>';
                        echo '<td><input type="text" id="bt'.$no.'" style="width: 60%"></td>';
                      
                        echo '<td><input type="text" id="for'.$no.'" style="width: 60%" class="kol1"></td>';
                        echo '<td><input type="text" id="er'.$no.'" style="width: 60%" class="kol2"></td>';
                        echo '<td><input type="text" id="mad'.$no.'" style="width: 60%" class="kol3"></td>';
                        echo '<td><input type="text" id="mse'.$no.'" style="width: 60%" class="kol4"></td>';
                        echo '<td><input type="text" id="mape'.$no.'" style="width: 60%" class="kol5"></td>';

                        $total_jum += $jum->singkat;
                    }
                  ?>
                </tr>
              <?php endforeach; ?>
                <tr align="center">
                  <td><b>TOTAL</b></td>
                  <td><input type="text" style="width: 60%" value="<?=$total_jum?>"></td>
                  <td colspan="4"></td>
                  <?php
                    for($i=1;$i<=5;$i++){
                      echo '<td><input type="text" style="width: 60%" id="ttl'.$i.'"></td>';
                    }
                  ?>
                </tr>
                <tr align="center">
                  <td colspan="8" align="right"><b>RATA - RATA</b></td>
                  <?php
                    for($i=3;$i<=5;$i++){
                      echo '<td><input type="text" style="width: 60%" id="rrt'.$i.'"></td>';
                    }
                  ?>
                </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
    <div class="card card-body shadow mb-4">
      <div class="table-responsive">
        <table class="table table-hover table-sm" width="100%" cellspacing="0">
          <thead>
            <tr align="center">
              <th>KETERANGAN</th>
              <th>NILAI</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th>ALPHA</th>
              <td><input type="text" class="form-control" id="dt" value="0.5" readonly=""/></td>
            </tr>
            <tr>
              <th>FORECAST</th>
              <td><input type="text" class="form-control" id="dt1" value="0" readonly=""/></td>
            </tr>
            <tr>
              <th>ERROR</th>
              <td><input type="text" class="form-control" id="dt2" value="0" readonly=""/></td>
            </tr>
            <tr>
              <th>MAD</th>
              <td><input type="text" class="form-control" id="dt3" value="0" readonly=""/></td>
            </tr>
            <tr>
              <th>MSE</th>
              <td><input type="text" class="form-control" id="dt4" value="0" readonly=""/></td>
            </tr>
            <tr>
              <th>MAPE</th>
              <td><input type="text" class="form-control" id="dt5" value="0" readonly=""/></td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  <?php endif; ?>

</div>

<script src="<?=base_url('assets/')?>vendor/jquery/jquery.min.js"></script>
<script type="text/javascript">
  $(function(){

    for(i=1;i<=<?=$no?>;i++){
    var sing = $('#singkat'+i).val();
    var jumlah=2;
      for(s=1;s<=jumlah;s++){
        var st = "#s"+i+"t"+s;
        if(sing == 0){
          var w = i - 1;
          var u = $("#s"+w+"t"+s).val();
          var st = "#s"+i+"t"+s;
          if(st == "#s"+i+"t1"){
            var jum = 0;
            hasil = jum.toFixed(1);
            $("#s"+i+"t1").val(hasil);
          }else if(st == "#s"+i+"t2"){
            var stt = $("#s"+i+"t1").val();
            var jumm = 0;
            hasil = jumm.toFixed(1);
            $("#s"+i+"t2").val(hasil);
          }
        }else{
          if((st == '#s1t1') || (st == '#s1t2')){
            var lt = sing-0;
            has = lt.toFixed(1);
            $("#s"+i+"t"+s).val(has);
          }else{
            var w = i - 1;
            var u = $("#s"+w+"t"+s).val();
            var st = "#s"+i+"t"+s;
            if(st == "#s"+i+"t1"){
              var jum = (0.5*sing)+(0.5*u);
              hasil = jum.toFixed(1);
              $("#s"+i+"t1").val(hasil);
            }else if(st == "#s"+i+"t2"){
              var stt = $("#s"+i+"t1").val();
              var jumm = (0.5*stt)+(0.5*u);
              hasil = jumm.toFixed(1);
              $("#s"+i+"t2").val(hasil);
            }
          }
        }

        var si = "#singkat"+i;
        if(si == '#singkat1'){
          var aat = (2 * sing) - sing;
          aatt = aat.toFixed(1);
          var btt = 0.5/(1-0.5)*(sing-sing);
          bbtt = btt.toFixed(1);
          var fo = aat + btt;
          foo = fo.toFixed(1);
          var er = Math.abs(sing - fo);
          err = er.toFixed(1);
          var mse = err * err;
          msee = mse.toFixed(1);
          var mape = er*100/sing; 
          mapee = mape.toFixed(1);
          $('#at'+i).val(aatt);
          $('#bt'+i).val(bbtt);
          $('#for'+i).val(foo);
          $('#er'+i).val(err);
          $('#mad'+i).val(err);
          $('#mse'+i).val(msee);
          $('#mape'+i).val(mapee);
        }else{
          var aat = (2 * jum) - jumm;
          aatt = aat.toFixed(1);
          var btt = 0.5/(1-0.5)*(jum-jumm);
          bbtt = btt.toFixed(1);
          var fo = aat + btt;
          foo = fo.toFixed(1);
          var er = Math.abs(sing - fo);
          err = er.toFixed(1);
          var mse = er * er;
          msee = mse.toFixed(1);
          var mape = er*100/sing; 
          mapee = mape.toFixed(1);
          $('#at'+i).val(aatt);
          $('#bt'+i).val(bbtt);
          $('#for'+i).val(foo);
          $('#er'+i).val(err);
          $('#mad'+i).val(err);
          $('#mse'+i).val(msee);
          $('#mape'+i).val(mapee);
        }

        for(c=1;c<=5;c++){
          var suum=0;
          $(".kol"+c).each(function(){
            suum+=parseFloat($(this).val());
          });
          
          var xx = suum;
          hasi = xx.toFixed(0);
          $('#dt'+c).val(hasi);
        }

      }
        total();
        rata();
    }

  });

  function total()
  {
    for(r=1;r<=5;r++){
      var sum=0;
      $(".kol"+r).each(function(){
        sum+=parseFloat($(this).val());
      });
      var fx=sum;
      tot = fx.toFixed(0);
      $("#ttl"+r).val(tot);
    }
  }

  function rata()
  {
    for(r=3;r<=5;r++){
      var tot = $("#ttl"+r).val();
      var rat = tot / <?=$no?>;
      rataa = rat.toFixed(2);
      $("#rrt"+r).val(rataa);
    }
  }
  
</script>